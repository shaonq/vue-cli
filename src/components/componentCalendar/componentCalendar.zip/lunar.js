var b = [43856, 19416, 19168, 42352, 21717, 53856, 55632, 25940, 22191, 39632, 21970, 19168, 42422, 42192, 53840, 53845, 46415, 54944, 44450, 38320, 18807, 18815, 42160, 46261, 27216, 27968, 43860, 11119, 38256, 21234, 18800, 25958, 54432, 59984, 27285, 23263, 11104, 34531, 37615, 51415, 51551, 54432, 55462, 46431, 22176, 42420, 9695, 37584, 53938, 43344, 46423, 27808, 46416, 21333, 19887, 42416, 17779, 21183, 43432, 59728, 27296, 44710, 43856, 19296, 43748, 42352, 21088, 62051, 55632, 23383, 22176, 38608, 19925, 19152, 42192, 54484, 53840, 54616, 46400, 46752, 38310, 38335, 18864, 43380, 42160, 45690, 27216, 27968, 44870, 43872, 38256, 19189, 18800, 25776, 29859, 59984, 27480, 23232, 43872, 38613, 37600, 51552, 55636, 54432, 55888, 30034, 22176, 43959, 9680, 37584, 51893, 43344, 46240, 47780, 44368, 21977, 19360, 42416, 20854, 21183, 43312, 31060, 27296, 44368, 23378, 19296, 42726, 42208, 53856, 60005, 54576, 23200, 30371, 38608, 19195, 19152, 42192, 53430, 53855, 54560, 56645, 46496, 22224, 21938, 18864, 42359, 42160, 43600, 45653, 27951, 44448, 19299, 37759, 18936, 18800, 25776, 26790, 59999, 27424, 42692, 43759, 37600, 53987, 51552, 54615, 54432, 55888, 23893, 22176, 42704, 21972, 21200, 43448, 43344, 46240, 46758, 44368, 21920, 43940, 42416, 21168, 45683, 26928, 29495, 27296, 44368, 19285, 19311, 42352, 21732, 53856, 59752, 54560, 55968, 27302, 22239, 19168, 43476, 42192, 53584, 62034, 54560]
    , f = ["9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c3598082c95f8c965cc920f", "97bd0b06bdb0722c965ce1cfcc920f", "b027097bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd0b06bdb0722c965ce1cfcc920f", "b027097bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd0b06bdb0722c965ce1cfcc920f", "b027097bd097c36b0b6fc9274c91aa", "9778397bd19801ec9210c965cc920e", "97b6b97bd19801ec95f8c965cc920f", "97bd09801d98082c95f8e1cfcc920f", "97bd097bd097c36b0b6fc9210c8dc2", "9778397bd197c36c9210c9274c91aa", "97b6b97bd19801ec95f8c965cc920e", "97bd09801d98082c95f8e1cfcc920f", "97bd097bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c91aa", "97b6b97bd19801ec95f8c965cc920e", "97bcf97c3598082c95f8e1cfcc920f", "97bd097bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c3598082c95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c3598082c95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd097bd07f595b0b6fc920fb0722", "9778397bd097c36b0b6fc9210c8dc2", "9778397bd19801ec9210c9274c920e", "97b6b97bd19801ec95f8c965cc920f", "97bd07f5307f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c920e", "97b6b97bd19801ec95f8c965cc920f", "97bd07f5307f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bd07f1487f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c9274c920e", "97bcf7f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c91aa", "97b6b97bd197c36c9210c9274c920e", "97bcf7f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c920e", "97b6b7f0e47f531b0723b0b6fb0722", "7f0e37f5307f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36b0b70c9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e37f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc9210c8dc2", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0787b0721", "7f0e27f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c91aa", "97b6b7f0e47f149b0723b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c8dc2", "977837f0e37f149b0723b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e37f5307f595b0b0bc920fb0722", "7f0e397bd097c35b0b6fc9210c8dc2", "977837f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e37f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc9210c8dc2", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f149b0723b0787b0721", "7f0e27f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14998082b0723b06bd", "7f07e7f0e37f149b0723b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e37f1487f595b0b0bb0b6fb0722", "7f0e37f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e37f1487f531b0b0bb0b6fb0722", "7f0e37f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e37f1487f531b0b0bb0b6fb0722", "7f0e37f0e37f14898082b072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e37f0e37f14898082b072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f149b0723b0787b0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14998082b0723b06bd", "7f07e7f0e47f149b0723b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14998082b0723b06bd", "7f07e7f0e37f14998083b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14898082b0723b02d5", "7f07e7f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e36665b66aa89801e9808297c35", "665f67f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e36665b66a449801e9808297c35", "665f67f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e36665b66a449801e9808297c35", "665f67f0e37f14898082b072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e26665b66a449801e9808297c35", "665f67f0e37f1489801eb072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722"]
    , c = ["小寒", "大寒", "立春", "雨水", "惊蛰", "春分", "清明", "谷雨", "立夏", "小满", "芒种", "夏至", "小暑", "大暑", "立秋", "处暑", "白露", "秋分", "寒露", "霜降", "立冬", "小雪", "大雪", "冬至"]
    , e = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"]
    , a = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"]
    , t = ["鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪"]
    , d = ["初", "十", "廿", "三十"]
    , n = ["", "一", "二", "三", "四", "五", "六", "七", "八", "九"]
    , r = ["正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "腊"]
    , u = {
        yearDataCache: {},
        getDate: function (b) {
            var f = new Date(1899, 1, 10)
                , c = /GMT(.*)/
                , e = 0;
            if (b.getTimezoneOffset() !== f.getTimezoneOffset()) {
                var a = f.toString().replace(c, b.toString().match(c)[0])
                    , t = new Date(a);
                e = Math.ceil((b - t) / 864e5)
            } else
                e = Math.ceil((b - new Date(1899, 1, 10)) / 864e5);
            for (var d, n, r, u, i, h = 1899; 2100 > h && e > 0; h++)
                d = this.getYearDays(h),
                    e -= d;
            for (0 > e && (e += d,
                h--),
                r = h,
                n = this.getLeapMonth(r) || !1,
                h = 1; 12 >= h; h++) {
                if (d = this.getMonthDays(r, h),
                    n === !0 && (n = !1,
                        h-- ,
                        d = this.getLeapDays(r),
                        d > e && (u = !0)),
                    n === h && (n = !0),
                    d > e) {
                    i = 30 === d;
                    break
                }
                e -= d
            }
            return {
                lunarYear: r,
                lunarMonth: h,
                lunarDay: e + 1,
                isLeap: u,
                isBigMonth: i
            }
        },
        getYearDays: function (f) {
            var c, e = this.yearDataCache;
            if (e[f])
                return e[f];
            var a = 348
                , t = b[f - 1899];
            for (c = 32768; c > 8; c >>= 1)
                a += c & t ? 1 : 0;
            return a += this.getLeapDays(f),
                e[f] = a,
                a
        },
        getLeapDays: function (f) {
            return this.getLeapMonth(f) ? b[f - 1899 + 1] & !0 ? 30 : 29 : 0
        },
        getLeapMonth: function (f) {
            var c = 15 & b[f - 1899];
            return 15 == c ? 0 : c
        },
        getMonthDays: function (f, c) {
            return b[f - 1899] & 65536 >> c ? 30 : 29
        }
    }
    , i = function (b, c) {
        for (var e, a = f[b - 1900], t = [], d = 0; 30 > d; d += 5)
            e = (+("0x" + a.substr(d, 5))).toString(),
                t.push(e.substr(0, 1)),
                t.push(e.substr(1, 2)),
                t.push(e.substr(3, 1)),
                t.push(e.substr(4, 2));
        return new Date(b, parseInt(c / 2, 10), t[c])
    }
    , h = {
        calculate: function (b) {
            return e[b % 10] + a[b % 12]
        },
        getGzYear: function (b, f, c) {
            return this.calculate(f - 1900 + 36 - (c === f ? 0 : 1))
        },
        getGzMonth: function (b, f, c) {
            var e = i(f, 2 * b.getMonth());
            return this.calculate(12 * (f - 1900) + c + 12 - (e > b ? 1 : 0))
        },
        getGzDay: function (b) {
            return this.calculate(Math.ceil(b / 864e5 + 25567 + 10))
        }
    }
    , o = {
        t0101: "t,春节 ",
        t0115: "t,元宵节",
        t0202: "t,龙头节",
        t0505: "t,端午节",
        t0707: "t,七夕节",
        t0715: "t,中元节",
        t0815: "t,中秋节",
        t0909: "t,重阳节",
        t1001: "t,寒衣节",
        t1015: "t,下元节",
        t1208: "t,腊八节",
        t1223: "t,小年",
        "0202": "i,湿地日,1996",
        "0308": "i,妇女节,1975",
        "0315": "i,消费者权益日,1983",
        "0401": "i,愚人节,1564",
        "0422": "i,地球日,1990",
        "0501": "i,劳动节,1889",
        "0512": "i,护士节,1912",
        "0518": "i,博物馆日,1977",
        "0605": "i,环境日,1972",
        "0623": "i,奥林匹克日,1948",
        1020: "i,骨质疏松日,1998",
        1117: "i,学生日,1942",
        1201: "i,艾滋病日,1988",
        "0101": "h,元旦",
        "0312": "h,植树节,1979",
        "0504": "h,五四青年节,1939",
        "0601": "h,儿童节,1950",
        "0701": "h,建党节,1941",
        "0801": "h,建军节,1933",
        "0903": "h,抗战胜利日,1945",
        "0910": "h,教师节,1985",
        1001: "h,国庆节,1949",
        1213: "h,国家公祭日,2014",
        1224: "c,平安夜",
        1225: "c,圣诞节",
        "0214": "a,情人节",
        w: {
            "0520": "i,母亲节,1913",
            "0630": "a,父亲节",
            1144: "a,感恩节"
        }
    }
    , l = function (b) {
        return 10 > b ? "0" + b : String(b)
    }
    , s = function (b, f) {
        var c, e = b.getFullYear(), a = b.getMonth() + 1, t = b.getDate(), d = b.getDay(), n = Math.ceil(t / 7), r = l(a) + n + d, u = "t" + l(f.lunarMonth) + l(f.lunarDay), i = l(a) + l(t), h = [];
        12 === f.lunarMonth && f.lunarDay === (f.isBigMonth ? 30 : 29) && h.push("t,除夕"),
            h = h.concat([o.w[r], o[i], o[u]]);
        for (var s = 0; s < h.length; s++)
            if (h[s]) {
                if (c = h[s].split(","),
                    c[2] && e < c[2]) {
                    h[s] = null;
                    continue
                }
                h[s] = {
                    type: c[0],
                    desc: c[1],
                    value: c[1]
                }
            }
        return h.sort(function (b, f) {
            return b && f ? b.type.charCodeAt(0) - f.type.charCodeAt(0) : b ? -1 : 1
        }),
            h.filter(function (b) {
                return b
            })
    }
    , g = function (b) {
        var f, e = b.getFullYear(), a = b.getMonth() + 1, o = b.getDate(), l = 2 * (a - 1), g = i(e, l), D = "";
        o != g.getDate() ? (f = i(e, l + 1),
            o == f.getDate() && (D = c[l + 1])) : D = c[l];
        var M = u.getDate(b);
        return {
            animal: t[(M.lunarYear - 4) % 12],
            gzDate: h.getGzDay(b),
            gzMonth: h.getGzMonth(b, e, a),
            gzYear: h.getGzYear(b, e, M.lunarYear),
            lunarYear: M.lunarYear,
            lunarMonth: M.lunarMonth,
            lunarDate: M.lunarDay,
            lMonth: (M.isLeap ? "闰" : "") + r[M.lunarMonth - 1],
            lDate: M.lunarDay % 10 == 0 ? ["初十", "二十", "三十"][M.lunarDay / 10 - 1] : d[parseInt(M.lunarDay / 10, 10)] + n[parseInt(M.lunarDay % 10, 10)],
            term: D,
            festival: function () {
                return s(b, M)
            },
            isBigMonth: M.isBigMonth,
            oDate: b,
            cnDay: "日一二三四五六七".charAt(b.getDay())
        }
    };

// lunar
export default g